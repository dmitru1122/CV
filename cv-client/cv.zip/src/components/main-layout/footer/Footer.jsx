import { React } from "react";
import "./Footer.scss";



function Footer() {
  return (
  <div className="footer">
      <div className="footer__title app-text app-text--white">FRONT-END</div>
  </div>
  )
}

export default Footer;